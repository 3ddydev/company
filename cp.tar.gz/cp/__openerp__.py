# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
# Copyright (C) 2018 EDISON GARCIA.
###############################################################

#__openerp__.py
{
'name':'Módule Company -CMT',
'version': '1.0',
'author': 'Edison Garcia',
'category': 'Accouting & Finance',
'summary':'Gestión de Compañias',
'sequence':40,
'description':"""
Es un módulo de ejemplo test
============================
Con este módulo se hara la primera tarea en Odoo 9.0
*
*
*
*
*
"""
'license': 'AGPL-3',
'depends': ['sale','base_setup','product','analytic','report'],
'data':[
'views/partner_view.xml',
'views/company',],
'installable': True,
'active': False,
'auto_install': False,
}