# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
# res_company.py

from openerp.osv import fields, osv
from openerp.tools.traslate import _

class res_partner(osv.osv):
	_name = 'res.partner'
	_inherit = 'res.partner'
	_columns= {
 	  		'categoria'fields.char('Catergoria', size=25, help='ingrese categoria'),

	}

res_partner()
