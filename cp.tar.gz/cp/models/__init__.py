# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
# Copyright (C) 2018 EDISON GARCIA.
###############################################################

# __init__.py
import res_company
################################
import cp