# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from openerp.osv import fields,osv

class cp(osv.osv):
	#declaracion el nombre comenzando con un prefijo
	_name = 'cm.cp'
	#buscador
	_rec_name ='nombre'
	_columns ={
		'nombre': fields.char ('Nombre', size=80, required=True, help='Debe colocar el nombre'),
		'partner_id' : fields.many2one('res.partner','Company',ondelete='restrict'),
		'country_id' : fields.many2one('res.country','City', ondelete='restrict'),


	}


cp();